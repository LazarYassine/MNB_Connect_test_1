package com.example.ClassMate_Pro;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ClassMateProApplication {

	public static void main(String[] args) {
		SpringApplication.run(ClassMateProApplication.class, args);
	}

}
